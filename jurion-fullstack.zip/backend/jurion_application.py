"""CQRS dispatch and use cases; infrastructure enters through ports."""

from collections.abc import Callable

from jurion_answer import answer
from jurion_commands import ImportCorpus, PublishSnapshot
from jurion_errors import SourceNotFound
from jurion_evidence import retrieve
from jurion_models import (
    KB_ID,
    Answer,
    KnowledgeBase,
    SnapshotAnswer,
    SourceChunk,
    SourceContent,
    SourceFile,
)
from jurion_ports import Catalog, Generator
from jurion_queries import (
    AnswerQuery,
    AnswerQuestion,
    GetSourceChunk,
    GetSourceFile,
    ListKnowledgeBases,
    ReadSnapshot,
)


def source_file(value: dict) -> SourceFile:
    return SourceFile(value["id"], value["name"], value["media_type"])


class Dispatcher:
    def __init__(
        self,
        catalog: Catalog,
        generator_factory: Callable[[], Generator] | None = None,
        retriever=retrieve,
    ):
        self.retriever = retriever
        self.catalog = catalog
        self.generator_factory = generator_factory
        self.handlers = {
            ImportCorpus: lambda cmd: self.catalog.import_archive(cmd.archive),
            PublishSnapshot: lambda cmd: self.catalog.publish(cmd.archive, cmd.catalog),
            ReadSnapshot: lambda query: self.catalog.load(query.snapshot_id),
            AnswerQuery: self._answer,
            AnswerQuestion: self._answer_question,
            ListKnowledgeBases: self._knowledge_bases,
            GetSourceChunk: self._source_chunk,
            GetSourceFile: self._source_file,
        }

    def _answer(self, query: AnswerQuery) -> Answer:
        return answer(
            query.manifest,
            query.messages,
            query.generator,
            as_of=query.as_of,
            deadline=query.deadline,
            retriever=self.retriever,
        )

    def _answer_question(self, query: AnswerQuestion) -> SnapshotAnswer:
        snapshot = self.catalog.load()
        if self.generator_factory is None:
            raise RuntimeError("Generator factory is required for AnswerQuestion")
        result = self._answer(
            AnswerQuery(
                snapshot.manifest,
                query.messages,
                self.generator_factory(),
                query.as_of,
                query.deadline,
            )
        )
        return SnapshotAnswer(snapshot.id, result)

    def _knowledge_bases(self, query: ListKnowledgeBases) -> tuple[KnowledgeBase, ...]:
        self.catalog.load()
        return (KnowledgeBase(KB_ID, "Корпус ООО «Меридиан»"),)

    def _source_chunk(self, query: GetSourceChunk) -> SourceChunk:
        snapshot = self.catalog.load(query.snapshot_id)
        chunk = next(
            (c for c in snapshot.manifest["chunks"] if c["id"] == query.chunk_id), None
        )
        if chunk is None:
            raise SourceNotFound("Source not found")
        file = next(
            f for f in snapshot.manifest["files"] if f["id"] == chunk["file_id"]
        )
        return SourceChunk(
            chunk["id"],
            snapshot.id,
            file["title"],
            chunk["text"],
            chunk["line_start"],
            chunk["line_end"],
            source_file(file),
            file["version_label"],
            chunk["provision_label"],
        )

    def _source_file(self, query: GetSourceFile) -> SourceContent:
        snapshot = self.catalog.load(query.snapshot_id)
        file = next(
            (f for f in snapshot.manifest["files"] if f["id"] == query.file_id), None
        )
        if file is None:
            raise SourceNotFound("Source not found")
        return SourceContent(source_file(file), snapshot.originals[file["id"]])

    def dispatch(self, request):
        return self.handlers[type(request)](request)
