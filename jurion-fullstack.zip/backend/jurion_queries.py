from dataclasses import dataclass
from datetime import date

from jurion_ports import Generator


@dataclass(frozen=True)
class ReadSnapshot:
    snapshot_id: str | None = None


@dataclass(frozen=True)
class AnswerQuery:
    manifest: dict
    messages: list[tuple[str, str]]
    generator: Generator
    as_of: date | None
    deadline: float


@dataclass(frozen=True)
class AnswerQuestion:
    messages: list[tuple[str, str]]
    as_of: date | None
    deadline: float


@dataclass(frozen=True)
class ListKnowledgeBases:
    pass


@dataclass(frozen=True)
class GetSourceChunk:
    snapshot_id: str
    chunk_id: str


@dataclass(frozen=True)
class GetSourceFile:
    snapshot_id: str
    file_id: str
