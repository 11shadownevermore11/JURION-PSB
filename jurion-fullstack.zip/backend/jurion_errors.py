"""Failures shared by application code and infrastructure adapters."""


class ModelUnavailable(Exception):
    def __init__(self, message, reason="unavailable"):
        super().__init__(message)
        self.reason = reason


class CatalogUnavailable(Exception):
    pass


class SourceNotFound(Exception):
    pass
