"""Structured answer rules, deterministic checks and semantic verification."""

import json
import re
import time
from datetime import date

from jurion_context import monetary_mentions, parse_context
from jurion_errors import ModelUnavailable
from jurion_evidence import retrieve
from jurion_models import OUTCOMES, Answer


def numbers(text):
    # Equivalent money representations (12 млн / 12 000 000 рублей) compare equally.
    for match, value in reversed(list(monetary_mentions(text))):
        text = text[: match.start()] + format(value, "f") + text[match.end() :]
    return set(
        re.findall(r"\d+(?:[.,]\d+)?", re.sub(r"(?<=\d)[ \u00a0](?=\d)", "", text))
    )


def normative_text(text, facts):
    """Exclude only explicitly scoped case amounts grounded in user provenance.

    This is not a blanket whitelist of numbers from the question: a contractual
    payment or a statutory threshold still must be supported by a source quote.
    The semantic verifier checks the legal conclusion and the stated comparison.
    """
    amount_facts = [f for f in facts if f.role == "amount"]
    latest_message = max((f.message for f in amount_facts), default=-1)
    amounts = {f.value for f in amount_facts if f.message == latest_message}
    spans = []
    for clause in re.finditer(
        r"\b(?:если|при сумме|при стоимости|для договора на)\b(?:(?!,(?!\d)|[;!?\n]).)*",
        text,
        re.IGNORECASE,
    ):
        mentions = list(monetary_mentions(clause[0]))
        if not mentions:
            continue
        match, value = mentions[0]
        prefix = clause[0][: match.start()]
        if (
            value in amounts
            and re.search(
                r"сумм|стоимост|договор", clause[0][: match.end()], re.IGNORECASE
            )
            and not re.search(
                r"порог|свыше|ставк|плат[аы]|штраф|требуется|одобрен",
                prefix,
                re.IGNORECASE,
            )
        ):
            spans.append((clause.start() + match.start(), clause.start() + match.end()))
    for start, end in reversed(spans):
        text = text[:start] + "указанная сумма" + text[end:]
    return text


def validate_draft(draft, evidence, facts=()):
    if (
        not isinstance(draft, dict)
        or not isinstance(draft.get("outcome"), str)
        or draft["outcome"] not in OUTCOMES
    ):
        raise ValueError("Invalid outcome")
    claims, missing = draft.get("claims"), draft.get("missing_information")
    if (
        not isinstance(claims, list)
        or len(claims) > 12
        or not isinstance(missing, list)
        or any(not isinstance(x, str) or not x.strip() for x in missing)
    ):
        raise ValueError("Invalid draft schema")
    index = {e["id"]: e for e in evidence}
    verified = []
    for claim in claims:
        if (
            not isinstance(claim, dict)
            or not isinstance(claim.get("text"), str)
            or not claim["text"].strip()
            or not isinstance(claim.get("citations"), list)
            or not claim["citations"]
        ):
            raise ValueError("Uncited claim")
        citations = []
        for citation in claim["citations"]:
            if not isinstance(citation, dict) or not isinstance(
                citation.get("chunk_id"), str
            ):
                raise ValueError("Invalid citation schema")  # noqa: TRY004 - malformed drafts use the validation retry path
            e = index.get(citation["chunk_id"])
            quote = citation.get("quote")
            if (
                e is None
                or not isinstance(quote, str)
                or not quote.strip()
                or quote not in e["text"]
            ):
                raise ValueError("Invalid quote")
            citations.append(
                {
                    "chunk_id": e["id"],
                    "label": e["source"]
                    + (", п. " + e["provision"] if e.get("provision") else ""),
                    "quote": quote,
                }
            )
        if not numbers(normative_text(claim["text"], facts)) <= numbers(
            " ".join(c["quote"] for c in citations)
        ):
            raise ValueError("Unsupported numeric fact")
        verified.append({"text": claim["text"], "citations": citations})
    outcome = draft["outcome"]
    if (
        outcome in ("answered", "invalid_premise", "partially_answered")
        and not verified
    ):
        raise ValueError("Substantive answer requires evidence")
    if outcome == "partially_answered" and not missing:
        raise ValueError("Missing gap")
    clarification = draft.get("clarification_question")
    if clarification is not None and (
        not isinstance(clarification, str) or not clarification.strip()
    ):
        raise ValueError("Invalid clarification")
    if outcome == "needs_clarification" and not clarification:
        raise ValueError("Missing clarification")
    return verified


def answer(
    manifest,
    messages,
    generator,
    *,
    as_of: date | None = None,
    deadline,
    retriever=retrieve,
):
    context = parse_context(messages, as_of)
    if context.date_conflict:
        return Answer(
            "needs_clarification",
            "Уточните противоречащую дату одного события.",
            clarification_question="Какая дата этого события верна?",
        )
    if len(context.document_candidates) > 1:
        return Answer(
            "needs_clarification",
            "Уточните контрагента: «Альфа-Трейд» или «Альфа-Трейдинг»?",
            clarification_question="Какой контрагент имеется в виду?",
        )
    evidence, missing = retriever(manifest, context, messages)
    if missing:
        return Answer(
            "needs_clarification",
            missing[0],
            missing_information=missing,
            clarification_question=missing[0],
        )
    question = json.dumps(
        {
            "last_question": context.question,
            "user_history": [t for r, t in messages if r == "user"],
            "dialogue_history": [{"role": r, "content": t} for r, t in messages],
            "legal_as_of": str(context.as_of_date) if context.as_of_date else None,
            "user_facts": [
                {
                    "role": f.role,
                    "value": str(f.value),
                    "message": f.message,
                    "span": f.span,
                    "precision": f.precision,
                }
                for f in context.resolved_facts
            ],
        },
        ensure_ascii=False,
    )
    for attempt in range(2):
        if time.monotonic() >= deadline:
            raise TimeoutError("Deadline exceeded")
        try:
            draft = generator.generate(question, evidence, deadline)
            claims = validate_draft(draft, evidence, context.resolved_facts)
            check = generator.verify(question, evidence, draft, deadline)
            if (
                not isinstance(check, dict)
                or check.get("supported") is not True
                or (
                    draft["outcome"] == "answered" and check.get("complete") is not True
                )
            ):
                raise ValueError("Unsupported or incomplete answer")
            break
        except ValueError as exc:
            question += (
                "\nПредыдущий черновик отклонён проверкой: "
                + str(exc)
                + ". Сформируйте исправленный ответ по тем же источникам."
            )
            if attempt:
                raise ModelUnavailable(
                    "Draft verification failed", reason="draft_rejected"
                ) from None
    notices = {
        "insufficient_evidence": "В доступном корпусе недостаточно оснований для ответа.",
        "out_of_scope": "Этот вопрос не относится к юридическому помощнику.",
        "disallowed": "Не могу помочь с противоправным действием. Могу разобрать требования по базе.",
        "needs_clarification": draft.get("clarification_question") or "",
    }
    text = "\n".join(
        c["text"]
        + " ("
        + "; ".join(dict.fromkeys(x["label"] for x in c["citations"]))
        + ")."
        for c in claims
    )
    if draft["outcome"] in notices:
        text = "\n".join(x for x in (notices[draft["outcome"]], text) if x)
    if draft["missing_information"]:
        text += "\nНе хватает: " + "; ".join(draft["missing_information"]) + "."
    if not text or len(text) > 10000:
        raise ModelUnavailable("Answer size invalid")
    return Answer(
        draft["outcome"],
        text,
        claims,
        draft["missing_information"],
        draft.get("clarification_question"),
        "organizer-proxy",
        generator.model,
    )
