"""In-memory search for the organizer's batch runner."""

from collections import Counter, defaultdict
from datetime import date
import math
import re

from jurion_search import tokens


STOPWORDS = frozenset("""
а ао вообще сразу только сам сама без был была были было бы в вам вас ведь весь во вот все вы где да для до
его ее если есть еще же за зачем и из или им их к как какая какое какие
какой когда ли мне можно мы на нам надо наш не него нее нет но нужно работник сотрудник человек о об
один он она они от по под после почему при про раз с так такой там то того
у уже хочу чем через что чтобы это этот я срок вопрос рф ооо
""".split())

# Aliases express search vocabulary only. The returned evidence comes from the archive.
ALIASES = (
    (r'юротдел|юрист', 'юридический отдел'),
    (r'аванс', 'предоплата'),
    (r'дефект|бракован', 'недостаток акт претензия'),
    (r'пени|пен[яиюе]', 'неустойка просрочка'),
    (r'транспорт|машин|грузовик|пропуска|ночью|ноч[иь]', 'доступ круглосуточно транспорт'),
    (r'съезжа|ключи|возврат помещен', 'прекращение возвращает помещение акт износ'),
    (r'проверить качеств|проверка качеств', 'приемка качество'),
    (r'сэд|электронн\w+ документооборот', 'СЭД лист согласования'),
    (r'компьютер|комплектующ', 'компьютерная техника'),
    (r'оператор\w* перс|персданн|\bпдн\b', 'персональные данные обработка'),
    (r'отозва|отзыв согласи|удалить.*данн', 'отзыв согласия обработка персональных данных'),
    (r'переработ|сверхуроч', 'сверхурочная работа'),
    (r'гендир|\bгд\b', 'генеральный директор одобрение'),
)

TOPICS = (
    (r'испытательн|срок испытани|испытани[еяию] (?:при|работник)', ('ТК_ст70',)),
    (r'сезонн|срочн\w+ трудов\w+ договор', ('ТК_ст59',)),
    (r'сверхуроч|переработ', ('ТК_ст99', 'ТК_ст152')),
    (r'минимальн\w+ размер\w* оплат|\bмрот\b|минималк', ('МРОТ_ст1',)),
    (r'\bндфл\b|налог\w* на доход\w* физ|налогов\w+ резидент|прогрессивн\w+ шкал', ('НК_ст224',)),
    (r'налог\w* на прибыл', ('НК_ст284',)),
    (r'\bндс\b|налог\w* на добавленн', ('НК_ст164',)),
    (r'освобожд|не платит|утрат\w+ прав|выручк', ('НК_ст145',)),
    (r'смягчающ|отягчающ', ('НК_ст112', 'НК_ст114')),
    (r'налогов\w+ санкц|налогов\w+ штраф', ('НК_ст114', 'НК_ст112')),
    (r'персональн\w+ данн|персданн|\bпдн\b', ('152ФЗ_ст9',)),
    (r'отозва|отзыв согласи|согласи\w+ на обработ', ('152ФЗ_ст9',)),
    (r'согласовани|согласова.*договор|одобрен|инициатор|генеральн\w+ директор|гендир|санкционн|иностранн\w+ контрагент|типов\w+ форм|оригинал|юротдел|руководител\w+ (?:отдел|подраздел)',
     ('Регламент согласования договоров',)),
    (r'архив|оригинал|копи\w+ договор', ('Служебная записка об архиве',)),
)

ARTICLE = re.compile(r'\bст(?:ать[яиею])?\.?\s*(\d+(?:\.\d+)?)', re.I)
TITLE_ARTICLE = re.compile(r'^(.+?)_ст(\d+(?:\.\d+)?)_')
INSTRUCTION = re.compile(r'для\s+ии[- ]ассистент|игнориру[ййте].{0,80}(?:инструкц|документ)', re.I)
APPLICABILITY = re.compile(r'^(?:действие положений|положения .{0,110} применя|абзац .{0,110} вступает|(?:статья|часть|пункт|подпункт|абзац) .{0,65} измен[её]н)', re.I)
CONTRACTS = {
    'А-08/2024': 'Договор аренды А-08-2024',
    'П-17/2024': 'Договор поставки П-17-2024',
    'ПТ-05/2023': 'Договор поставки ПТ-05-2023',
}
YEAR = re.compile(r'(?<!\d)(?:19|20)\d{2}(?!\d)')
MAX_CONTEXT = 10000


def terms(text):
    return [word for word in tokens(text) if word not in STOPWORDS]


def features(text):
    normalized = text.lower().replace('ё', 'е')
    extras = ' '.join(extra for pattern, extra in ALIASES if re.search(pattern, normalized))
    return set(terms(text)), set(terms(extras))


def citation(title, provision):
    match = TITLE_ARTICLE.match(title)
    if match:
        code = {'152ФЗ': 'Федеральный закон № 152-ФЗ', 'МРОТ': 'Федеральный закон № 82-ФЗ',
                'НК': 'НК РФ', 'ТК': 'ТК РФ', 'КоАП': 'КоАП РФ'}.get(match[1], match[1])
        return f'{code}, ст. {match[2]}' + (f', {provision}' if provision else '')
    return title + (f', п. {provision}' if provision else '')


class CorpusSearch:
    def __init__(self, manifest):
        self.files = {source['id']: source for source in manifest['files']}
        self.items = []
        self.by_file = defaultdict(list)
        self.postings = defaultdict(list)
        for chunk in manifest['chunks']:
            source = self.files[chunk['file_id']]
            fid, body = source['id'], chunk['text'].strip()
            if not body or INSTRUCTION.search(body):
                continue
            statute = source['coverage_kind'] == 'statute_excerpt'
            note = statute and APPLICABILITY.match(body)
            if not note and chunk['content_kind'] != 'normative_text':
                continue
            provision = chunk.get('provision_label')
            words = terms(body)
            index = len(self.items)
            self.items.append({
                'file_id': fid, 'line': chunk['line_start'], 'text': body,
                'label': citation(source['title'], provision),
                'provision': provision, 'size': len(words),
                'note': bool(note),
            })
            self.by_file[fid].append(index)
            for term, count in Counter(words).items():
                self.postings[term].append((index, count))
        self.position = {item: pos for group in self.by_file.values()
                         for pos, item in enumerate(group)}
        self.avg_length = sum(x['size'] for x in self.items) / max(1, len(self.items)) or 1

    def _scores(self, question, earlier):
        last, expanded = features(question)
        history, history_expanded = features(earlier)
        weights = dict.fromkeys(history | history_expanded, 0.32)
        weights.update(dict.fromkeys(expanded, 0.60))
        weights.update(dict.fromkeys(last, 1.0))
        scores = defaultdict(float)
        count = len(self.items)
        for term, weight in sorted(weights.items()):
            hits = self.postings.get(term, ())
            if not hits:
                continue
            idf = math.log1p((count - len(hits) + .5) / (len(hits) + .5))
            if term.isdigit():
                weight *= .3
            for index, frequency in hits:
                length_weight = .45 + .55 * self.items[index]['size'] / self.avg_length
                scores[index] += weight * idf * frequency * 2.2 / (frequency + 1.2 * length_weight)
        return scores

    def select(self, context, messages):
        question = context.question
        earlier = ' '.join(text for role, text in messages[:-1] if role == 'user')
        query = (earlier + ' ' + question).lower().replace('ё', 'е')
        scores = self._scores(question, earlier)
        hints = {name for pattern, names in TOPICS if re.search(pattern, query) for name in names}
        if '152ФЗ_ст9' in hints and re.search(r'штраф|коап|административн\w+ ответственност', query):
            hints.add('КоАП_ст13.11')
        if 'НК_ст164' not in hints:
            hints.discard('НК_ст145')
        elif 'НК_ст145' in hints:
            hints.discard('НК_ст164')
        requested_articles = set(ARTICLE.findall(question))
        contracts = tuple(CONTRACTS[key] for key in context.document_candidates)
        if not contracts and re.search(r'договор', query):
            if re.search(r'аренд|помещен|арендн', query):
                contracts = (CONTRACTS['А-08/2024'],)
        distribution = re.search(r'адрес|куда (?:привез|постав|достав)|куда.*(?:товар|парти)|место достав|какой склад|ул\.|заводск|складск', query)
        compare_versions = bool(re.search(r'сравн|отлича|изменил|прежн|стар\w+ редакц|прошл\w+ редакц|обе\w* редакц|до и после', query))
        years = {int(value) for value in YEAR.findall(question)}
        as_of = context.as_of_date
        if as_of is None and len(years) == 1 and re.search(r'регламент|согласован|одобрен', query):
            year = next(iter(years))
            # March is a transition month in 2025. Let the model describe both rules.
            if year != 2025:
                as_of = date(year, 7, 1)
        applicable_files = set()
        preferred = set()
        corporate_context = any(prefix.startswith(('Регламент', 'Служебная')) for prefix in hints)
        for fid, source in self.files.items():
            title = source['title']
            if title.startswith('Доп соглашение'):
                if distribution and CONTRACTS['П-17/2024'] in contracts:
                    applicable_files.add(fid)
                    preferred.add(fid)
                continue
            if title.startswith('Письмо комплаенс'):
                if re.search(r'иностранн|санкц|комплаенс|валютн|к-12', query):
                    applicable_files.add(fid)
                    preferred.add(fid)
                continue
            if source['version_label'] and not compare_versions:
                if as_of is None:
                    if source['version_label'] == '2023' and not (2025 in years and corporate_context):
                        continue
                else:
                    end = context.interval_end or as_of
                    if source['effective_from'] and end < date.fromisoformat(source['effective_from']):
                        continue
                    if source['effective_to'] and as_of >= date.fromisoformat(source['effective_to']):
                        continue
            applicable_files.add(fid)
            match = TITLE_ARTICLE.match(title)
            if any(title.startswith(prefix + '_') if '_ст' in prefix else title.startswith(prefix)
                   for prefix in hints | set(contracts)):
                preferred.add(fid)
            if match and match[2] in requested_articles:
                preferred.add(fid)

        if contracts:
            last = question.lower().replace('ё', 'е')
            cross_domain = (requested_articles or compare_versions or re.search(
                r'(?:(?:тк|нк|коап) рф|закон|по регламенту|согласован|одобрен|налогооблож|налогов\w+ ставк)',
                last,
            ))
            if not cross_domain:
                applicable_files = {fid for fid in applicable_files
                                    if self.files[fid]['title'].startswith(contracts)
                                    or self.files[fid]['title'].startswith('Доп соглашение')}
            contract_prefixes = tuple(CONTRACTS.values())
            applicable_files = {fid for fid in applicable_files
                                if not self.files[fid]['title'].startswith(contract_prefixes)
                                or self.files[fid]['title'].startswith(contracts)}

        if preferred and not contracts:
            applicable_files &= preferred
        ranked = sorted(
            (index for index, score in scores.items()
             if score > 0 and self.items[index]['file_id'] in applicable_files),
            key=lambda index: (-(scores[index] * (1.65 if self.items[index]['file_id'] in preferred else 1)
                                * (.65 if self.items[index]['note'] else 1)), index),
        )
        primary = preferred & applicable_files
        if not primary:
            primary = {self.items[index]['file_id'] for index in ranked[:3]}
            ranked = [index for index in ranked if self.items[index]['file_id'] in primary]
        chosen = set()
        used = 0

        def add(index, limit=MAX_CONTEXT):
            nonlocal used
            item = self.items[index]
            size = len(item['text']) + len(item['label']) + 35
            if index not in chosen and used + size <= limit:
                chosen.add(index)
                used += size

        # All operative clauses of a named contract fit in a short, coherent block.
        for fid in self.files:
            title = self.files[fid]['title']
            if fid not in primary or not (title.startswith(contracts) or
                                           title.startswith(('Доп соглашение', 'Письмо комплаенс'))):
                continue
            group = self.by_file[fid]
            for index in group:
                if (self.items[index]['provision'] or
                    title.startswith(('Доп соглашение', 'Письмо комплаенс'))):
                    add(index, 7600)

        if re.search(r'ставк|процент|сколько', question.lower()):
            for fid in sorted(primary):
                title = self.files[fid]['title']
                if title.startswith(('НК_ст164_', 'НК_ст224_', 'НК_ст284_')):
                    group = self.by_file[fid]
                    for pos, index in enumerate(group):
                        body = self.items[index]['text']
                        if re.match(r'^\d\. (?:Налогов\w+ ставк|Налогообложение производится)', body, re.I):
                            add(index, 4600)
                            if title.startswith('НК_ст224_') and body.startswith('1.'):
                                for neighbor in group[pos + 1:pos + 11]:
                                    add(neighbor, 4600)

        # Reserve space for the top matches from each relevant document.
        counts = Counter()
        for index in ranked:
            fid = self.items[index]['file_id']
            if fid not in primary or counts[fid] >= 4:
                continue
            add(index, 8400)
            counts[fid] += 1

        # Keep nearby exceptions, paragraph continuations and date annotations.
        for index in ranked[:25]:
            if index not in chosen:
                continue
            item = self.items[index]
            group = self.by_file[item['file_id']]
            pos = self.position[index]
            for neighbor in group[max(0, pos - 2):pos + 3]:
                other = self.items[neighbor]
                if abs(other['line'] - item['line']) <= 7:
                    add(neighbor, 9300)

        limits = Counter()
        for index in ranked:
            fid = self.items[index]['file_id']
            if limits[fid] < (6 if fid in primary else 2):
                add(index)
                limits[fid] += 1
            if len(chosen) >= 42 or used >= MAX_CONTEXT - 150:
                break

        evidence = []
        for index in sorted(chosen, key=lambda i: (self.items[i]['file_id'] not in primary, i)):
            item = self.items[index]
            source = self.files[item['file_id']]
            entry = {'id': len(evidence) + 1, 'source': item['label'], 'text': item['text']}
            if item['note']:
                entry['type'] = 'редакционное примечание о сроке действия'
            if source['version_label']:
                entry['valid_from'] = source['effective_from']
                if source['effective_to']:
                    entry['valid_until_exclusive'] = source['effective_to']
            if source.get('observed_on'):
                entry['snapshot_date'] = source['observed_on']
            evidence.append(entry)
        return evidence
