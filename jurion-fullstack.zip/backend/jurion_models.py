from dataclasses import dataclass, field

OUTCOMES = {
    "answered",
    "partially_answered",
    "needs_clarification",
    "insufficient_evidence",
    "invalid_premise",
    "out_of_scope",
    "disallowed",
}


@dataclass
class Answer:
    outcome: str
    text: str
    claims: list[dict] = field(default_factory=list)
    missing_information: list[str] = field(default_factory=list)
    clarification_question: str | None = None
    provider: str | None = None
    model: str | None = None


KB_ID = "meridian"


@dataclass(frozen=True)
class KnowledgeBase:
    id: str
    title: str


@dataclass(frozen=True)
class SourceFile:
    id: str
    name: str
    media_type: str


@dataclass(frozen=True)
class SourceChunk:
    chunk_id: str
    snapshot_id: str
    document_title: str
    text: str
    line_start: int
    line_end: int
    file: SourceFile
    version_label: str | None
    provision_label: str | None


@dataclass(frozen=True)
class SourceContent:
    file: SourceFile
    content: bytes


@dataclass(frozen=True)
class SnapshotAnswer:
    snapshot_id: str
    answer: Answer
