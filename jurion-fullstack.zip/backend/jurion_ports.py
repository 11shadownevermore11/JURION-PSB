from dataclasses import dataclass
from pathlib import Path
from typing import Protocol


class Generator(Protocol):
    model: str

    def generate(self, question, evidence, deadline): ...
    def verify(self, question, evidence, draft, deadline): ...


@dataclass(frozen=True)
class Snapshot:
    id: str
    manifest: dict
    originals: dict[str, bytes]


class Catalog(Protocol):
    def import_archive(self, archive: Path) -> tuple[dict, dict[str, bytes]]: ...
    def publish(self, archive: Path, root: Path) -> str: ...
    def load(self, snapshot_id: str | None = None) -> Snapshot: ...
