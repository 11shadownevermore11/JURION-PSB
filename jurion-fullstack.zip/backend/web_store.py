"""SQLite storage for browser sessions, conversations and answer runs."""

from contextlib import closing, contextmanager
from datetime import UTC, datetime
import json
from pathlib import Path
import sqlite3
from uuid import uuid4


def now():
    return datetime.now(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def new_id():
    return uuid4().hex


def error(code, message, *, retryable=False, **details):
    return dict(code=code, message=message, retryable=retryable, **details)


class ApiFailure(Exception):
    def __init__(self, status, code, message, *, retryable=False, **details):
        super().__init__(message)
        self.status = status
        self.error = error(code, message, retryable=retryable, **details)


def not_found():
    return ApiFailure(404, "NOT_FOUND", "Ресурс не найден.")


def invalid(message, field):
    return ApiFailure(
        422, "VALIDATION_ERROR", message,
        field_errors=[{"field": field, "message": message}],
    )


class Store:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(path)) as setup:
            setup.execute("PRAGMA journal_mode=WAL")
        with self.connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS sessions (
                    id TEXT PRIMARY KEY
                );
                CREATE TABLE IF NOT EXISTS conversations (
                    id TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL REFERENCES sessions(id),
                    knowledge_base_id TEXT NOT NULL,
                    title TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS conversation_activity
                    ON conversations(session_id, updated_at DESC, id DESC);
                CREATE TABLE IF NOT EXISTS messages (
                    id TEXT PRIMARY KEY,
                    conversation_id TEXT NOT NULL REFERENCES conversations(id),
                    seq INTEGER NOT NULL,
                    role TEXT NOT NULL,
                    text TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    answer TEXT,
                    UNIQUE(conversation_id, seq)
                );
                CREATE TABLE IF NOT EXISTS runs (
                    id TEXT PRIMARY KEY,
                    conversation_id TEXT NOT NULL REFERENCES conversations(id),
                    user_id TEXT NOT NULL REFERENCES messages(id),
                    as_of TEXT,
                    state TEXT NOT NULL,
                    assistant_id TEXT REFERENCES messages(id),
                    error TEXT
                );
                CREATE INDEX IF NOT EXISTS runs_by_conversation ON runs(conversation_id);
                CREATE UNIQUE INDEX IF NOT EXISTS one_active_run
                    ON runs(conversation_id) WHERE state = 'running';
                CREATE TABLE IF NOT EXISTS idempotency (
                    session_id TEXT NOT NULL REFERENCES sessions(id),
                    key TEXT NOT NULL,
                    signature TEXT NOT NULL,
                    run_id TEXT NOT NULL REFERENCES runs(id),
                    PRIMARY KEY(session_id, key)
                );
            """)
            # A single API process owns this database and its background jobs.
            db.execute(
                "UPDATE runs SET state = 'failed', error = ? WHERE state = 'running'",
                (json.dumps(error("MODEL_UNAVAILABLE", "Сервер перезапустился. Повторите запрос.", retryable=True)),),
            )

    @contextmanager
    def connect(self, *, write=False):
        db = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        try:
            db.execute("BEGIN IMMEDIATE" if write else "BEGIN")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def session(self, key, *, create=False):
        with self.connect(write=create) as db:
            if key and db.execute("SELECT 1 FROM sessions WHERE id = ?", (key,)).fetchone():
                return key
            if not create:
                raise ApiFailure(401, "SESSION_REQUIRED", "Откройте сессию заново.")
            key = new_id()
            db.execute("INSERT INTO sessions VALUES (?)", (key,))
            return key

    @staticmethod
    def conversation(db, session, cid):
        row = db.execute(
            """SELECT id, knowledge_base_id, title, created_at, updated_at
               FROM conversations WHERE id = ? AND session_id = ?""", (cid, session),
        ).fetchone()
        if row is None:
            raise not_found()
        return dict(row)

    def create_conversation(self, session, kb):
        cid, timestamp = new_id(), now()
        with self.connect(write=True) as db:
            db.execute(
                "INSERT INTO conversations VALUES (?, ?, ?, ?, ?, ?)",
                (cid, session, kb, "Новый диалог", timestamp, timestamp),
            )
            return self.conversation(db, session, cid)

    def conversations(self, session, limit, offset):
        with self.connect() as db:
            rows = db.execute(
                """SELECT id, knowledge_base_id, title, created_at, updated_at
                   FROM conversations WHERE session_id = ?
                   ORDER BY updated_at DESC, id DESC LIMIT ? OFFSET ?""",
                (session, limit + 1, offset),
            ).fetchall()
        return {
            "items": [dict(row) for row in rows[:limit]],
            "next_cursor": str(offset + limit) if len(rows) > limit else None,
        }

    @staticmethod
    def message(row):
        value = {key: row[key] for key in ("id", "seq", "role", "text", "created_at")}
        if row["answer"] is not None:
            value["answer"] = json.loads(row["answer"])
        return value

    @staticmethod
    def latest(db, cid):
        return db.execute(
            "SELECT * FROM runs WHERE conversation_id = ? ORDER BY rowid DESC LIMIT 1", (cid,),
        ).fetchone()

    def messages(self, session, cid, limit, before):
        with self.connect() as db:
            conversation = self.conversation(db, session, cid)
            rows = db.execute(
                """SELECT * FROM messages WHERE conversation_id = ? AND seq < ?
                   ORDER BY seq DESC LIMIT ?""",
                (cid, before, limit + 1),
            ).fetchall()
            latest = self.latest(db, cid)
        return {
            "conversation": conversation,
            "items": [self.message(row) for row in reversed(rows[:limit])],
            "next_before_seq": rows[limit - 1]["seq"] if len(rows) > limit else None,
            "latest_run_id": latest["id"] if latest else None,
        }

    @staticmethod
    def owned_run(db, session, rid):
        run = db.execute(
            """SELECT runs.* FROM runs JOIN conversations
               ON conversations.id = runs.conversation_id
               WHERE runs.id = ? AND conversations.session_id = ?""", (rid, session),
        ).fetchone()
        if run is None:
            raise not_found()
        return run

    def run(self, session, rid):
        with self.connect() as db:
            run = self.owned_run(db, session, rid)
            user = db.execute("SELECT * FROM messages WHERE id = ?", (run["user_id"],)).fetchone()
            assistant = db.execute(
                "SELECT * FROM messages WHERE id = ?", (run["assistant_id"],),
            ).fetchone()
        failure = json.loads(run["error"]) if run["error"] else None
        if failure:
            failure["run_id"] = rid
        return {
            "run_id": rid, "conversation_id": run["conversation_id"],
            "state": run["state"], "user_message": self.message(user),
            "assistant_message": self.message(assistant) if assistant else None,
            "error": failure,
        }

    @staticmethod
    def replay(db, session, key, signature):
        prior = db.execute(
            "SELECT signature, run_id FROM idempotency WHERE session_id = ? AND key = ?",
            (session, key),
        ).fetchone()
        if prior and prior["signature"] != signature:
            raise ApiFailure(409, "IDEMPOTENCY_CONFLICT", "Ключ уже использован для другого запроса.")
        return prior["run_id"] if prior else None

    @staticmethod
    def reserve(db, session, key, signature, cid, user, as_of):
        queue = db.execute("SELECT COUNT(*) FROM runs WHERE state = 'running'").fetchone()[0]
        if queue >= 32:
            raise ApiFailure(429, "RATE_LIMITED", "Очередь заполнена. Повторите позже.", retryable=True)
        rid = new_id()
        db.execute(
            "INSERT INTO runs VALUES (?, ?, ?, ?, 'running', NULL, NULL)",
            (rid, cid, user, as_of),
        )
        db.execute(
            "INSERT INTO idempotency VALUES (?, ?, ?, ?)", (session, key, signature, rid),
        )
        return rid

    def send(self, session, cid, key, text, as_of):
        signature = json.dumps(["send", cid, text, as_of], ensure_ascii=False)
        with self.connect(write=True) as db:
            conv = self.conversation(db, session, cid)
            prior = self.replay(db, session, key, signature)
            if prior:
                return prior, False
            latest = self.latest(db, cid)
            if latest and latest["state"] == "running":
                raise ApiFailure(409, "RUN_IN_PROGRESS", "Предыдущий вопрос ещё обрабатывается.", run_id=latest["id"])
            seq = db.execute(
                "SELECT COALESCE(MAX(seq), 0) + 1 FROM messages WHERE conversation_id = ?", (cid,),
            ).fetchone()[0]
            uid, timestamp = new_id(), now()
            db.execute(
                "INSERT INTO messages VALUES (?, ?, ?, 'user', ?, ?, NULL)",
                (uid, cid, seq, text, timestamp),
            )
            title = " ".join(text.split())
            title = title if len(title) <= 56 else title[:55].rstrip() + "…"
            db.execute(
                "UPDATE conversations SET title = ?, updated_at = ? WHERE id = ?",
                (title if seq == 1 else conv["title"], timestamp, cid),
            )
            return self.reserve(db, session, key, signature, cid, uid, as_of), True

    def retry(self, session, rid, key):
        signature = json.dumps(["retry", rid])
        with self.connect(write=True) as db:
            run = self.owned_run(db, session, rid)
            prior = self.replay(db, session, key, signature)
            if prior:
                return prior, False
            cid = run["conversation_id"]
            if (
                run["state"] != "failed"
                or not json.loads(run["error"])["retryable"]
                or self.latest(db, cid)["id"] != rid
            ):
                raise ApiFailure(409, "RETRY_NOT_AVAILABLE", "Повтор для этой попытки недоступен.")
            return self.reserve(db, session, key, signature, cid, run["user_id"], run["as_of"]), True

    def input_for(self, rid):
        with self.connect() as db:
            run = db.execute("SELECT * FROM runs WHERE id = ?", (rid,)).fetchone()
            rows = db.execute(
                """SELECT role, text FROM messages WHERE conversation_id = ?
                   AND seq <= (SELECT seq FROM messages WHERE id = ?)
                   ORDER BY seq DESC LIMIT 24""", (run["conversation_id"], run["user_id"]),
            ).fetchall()
        as_of = run["as_of"]
        return [(row["role"], row["text"]) for row in reversed(rows)], as_of

    def complete(self, rid, answer, text):
        with self.connect(write=True) as db:
            run = db.execute(
                """SELECT runs.conversation_id, messages.seq FROM runs
                   JOIN messages ON messages.id = runs.user_id
                   WHERE runs.id = ? AND runs.state = 'running'""", (rid,),
            ).fetchone()
            if run is None:
                return
            aid, timestamp = new_id(), now()
            db.execute(
                "INSERT INTO messages VALUES (?, ?, ?, 'assistant', ?, ?, ?)",
                (aid, run["conversation_id"], run["seq"] + 1, text, timestamp, json.dumps(answer, ensure_ascii=False)),
            )
            db.execute("UPDATE runs SET state = 'completed', assistant_id = ? WHERE id = ?", (aid, rid))
            db.execute(
                "UPDATE conversations SET updated_at = ? WHERE id = ?",
                (timestamp, run["conversation_id"]),
            )

    def fail(self, rid, failure):
        with self.connect(write=True) as db:
            db.execute(
                "UPDATE runs SET state = 'failed', error = ? WHERE id = ? AND state = 'running'",
                (json.dumps(failure, ensure_ascii=False), rid),
            )
