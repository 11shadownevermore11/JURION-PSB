"""Standalone entry point for the organizer’s evaluation container."""

import csv
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from jurion_batch import answer_batch
from jurion_corpus import build_snapshot
from jurion_infra_proxy import ProxyGenerator, env_value, worker_limit
from jurion_rag import CorpusSearch

RUN_BUDGET_SECONDS = 19 * 60
QUESTION_BUDGET_SECONDS = 90
TECHNICAL_FAILURE = (
    "Техническая ошибка при обработке вопроса; повторите запрос позднее."
)


def write_submission(rows, results):
    # Every checkpoint contains the full input ID set, even if the runner is stopped.
    temporary = Path("submission.csv.tmp")
    with temporary.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["id", "answer"])
        for row, result in zip(rows, results):
            writer.writerow([row["id"], result])
    temporary.replace("submission.csv")


def history(text):
    parts = re.split(r"(?im)^\s*(Пользователь|Ассистент|user|assistant)\s*:\s*", text)
    if len(parts) == 1:
        return [("user", text)]
    messages = [("user", parts[0].strip())] if parts[0].strip() else []
    for i in range(1, len(parts) - 1, 2):
        message = parts[i + 1].strip()
        if message:
            role = "user" if parts[i].lower() in ("пользователь", "user") else "assistant"
            messages.append((role, message))
    for i in range(len(messages) - 1, -1, -1):
        if messages[i][0] == "user":
            return messages[:i + 1]
    return [("user", text)]


def main():
    deadline = time.monotonic() + RUN_BUDGET_SECONDS
    data_dir = Path(env_value("DATA_DIR", default="data"))
    with (data_dir / "questions.csv").open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or not {"id", "question"} <= set(reader.fieldnames):
            raise ValueError("questions.csv requires id and question columns")
        rows = list(reader)
    ids = [row["id"] for row in rows]
    if any(not isinstance(value, str) or not value.strip() for value in ids) or len(
        set(ids)
    ) != len(ids):
        raise ValueError("Question IDs must be nonempty and unique")
    results = [TECHNICAL_FAILURE] * len(rows)
    write_submission(rows, results)
    try:
        # The regulation uses knowledge-base.zip; the starter also uses kb.zip.
        archive = next(
            (
                data_dir / name
                for name in ("knowledge-base.zip", "kb.zip", "knowledge_base.zip")
                if (data_dir / name).is_file()
            ),
            data_dir / "knowledge-base.zip",
        )
        manifest, _ = build_snapshot(archive)
        search = CorpusSearch(manifest)
        failure = None
    except Exception as exc:  # noqa: BLE001 - the batch must still produce all input IDs
        print("Corpus import failed: " + type(exc).__name__, file=sys.stderr)
        search, failure = None, "Техническая ошибка загрузки базы знаний."

    def run(row):
        if failure:
            return failure
        try:
            if time.monotonic() >= deadline:
                raise TimeoutError("Batch deadline exceeded")
            question_deadline = min(
                deadline, time.monotonic() + QUESTION_BUDGET_SECONDS
            )
            return answer_batch(
                search,
                history(row.get("question") or ""),
                ProxyGenerator.from_env(),
                question_deadline,
            )
        except Exception as exc:  # noqa: BLE001 - isolate each independent test case
            # Do not print exception bodies: provider errors may contain secrets.
            print("Question processing failed: " + type(exc).__name__, file=sys.stderr)
            return TECHNICAL_FAILURE

    last_checkpoint = time.monotonic()
    with ThreadPoolExecutor(max_workers=worker_limit()) as executor:
        pending = {executor.submit(run, row): i for i, row in enumerate(rows)}
        for future in as_completed(pending):
            results[pending[future]] = future.result()
            if time.monotonic() - last_checkpoint >= 1:
                write_submission(rows, results)
                last_checkpoint = time.monotonic()
    write_submission(rows, results)
    print(f"Created submission.csv: {len(rows)} answers", flush=True)


if __name__ == "__main__":
    main()
