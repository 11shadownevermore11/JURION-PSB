from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ImportCorpus:
    archive: Path


@dataclass(frozen=True)
class PublishSnapshot:
    archive: Path
    catalog: Path
