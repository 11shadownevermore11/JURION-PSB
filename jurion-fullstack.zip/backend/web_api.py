"""HTTP adapter for the Jurion browser application."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from datetime import date
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import logging
from pathlib import Path
import re
import time
from urllib.parse import parse_qs, urlsplit

from jurion_application import Dispatcher
from jurion_commands import PublishSnapshot
from jurion_errors import CatalogUnavailable, ModelUnavailable, SourceNotFound
from jurion_infra_catalog import FileCatalog
from jurion_infra_proxy import ProxyGenerator, env_value, worker_limit
from jurion_queries import AnswerQuestion, GetSourceChunk, GetSourceFile, ListKnowledgeBases, ReadSnapshot
from web_store import ApiFailure, Store, error, invalid, not_found

API = "/api/v1"
ID = r"[0-9a-f]{32}"
SNAPSHOT = r"[0-9a-f]{64}"
MESSAGES = re.compile(rf"{API}/conversations/({ID})/messages")
RUN = re.compile(rf"{API}/runs/({ID})")
RETRY = re.compile(rf"{API}/runs/({ID})/retry")
SOURCE = re.compile(rf"{API}/sources/({SNAPSHOT})/(chunks|files)/({ID})")
SESSION_COOKIE = "jurion_session"
LOG = logging.getLogger("jurion.web")


class WebApplication:
    def __init__(self, store, dispatcher, workers):
        self.store = store
        self.dispatcher = dispatcher
        self.workers = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="jurion-answer")

    def queue_run(self, rid):
        try:
            self.workers.submit(self.answer, rid, time.monotonic() + 90)
        except RuntimeError:
            self.store.fail(rid, error("MODEL_UNAVAILABLE", "Сервер останавливается.", retryable=True))

    def answer(self, rid, deadline):
        try:
            if time.monotonic() >= deadline:
                raise TimeoutError
            messages, as_of = self.store.input_for(rid)
            result = self.dispatcher.dispatch(
                AnswerQuestion(messages, date.fromisoformat(as_of) if as_of else None, deadline),
            )
            answer = result.answer
            claims = [
                dict(claim, id=f"claim_{number:02}")
                for number, claim in enumerate(answer.claims, 1)
            ]
            payload = {
                "outcome": answer.outcome, "snapshot_id": result.snapshot_id, "claims": claims,
                "missing_information": answer.missing_information,
                "clarification_question": answer.clarification_question,
            }
            self.store.complete(rid, payload, answer.text)
        except TimeoutError:
            self.store.fail(rid, error("ANSWER_TIMEOUT", "Ответ не сформирован за отведённое время.", retryable=True))
        except CatalogUnavailable:
            self.store.fail(rid, error("CATALOG_UNAVAILABLE", "База знаний недоступна.", retryable=True))
        except ModelUnavailable:
            self.store.fail(rid, error("MODEL_UNAVAILABLE", "Модель недоступна или не прошла проверку ответа.", retryable=True))
        except Exception as exc:
            LOG.error("Answer run failed (%s)", type(exc).__name__)
            self.store.fail(rid, error("INTERNAL_ERROR", "Не удалось обработать запрос.", retryable=True))


class Handler(BaseHTTPRequestHandler):
    server_version = "Jurion"
    sys_version = ""

    def setup(self):
        super().setup()
        self.connection.settimeout(15)

    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")

    def log_message(self, format, *args):
        # Request urls and exception payloads may contain internal identifiers.
        return

    def reply(self, status, value, *, cookie=None, content_type="application/json; charset=utf-8"):
        data = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if status == 429:
            self.send_header("Retry-After", "2")
        if cookie:
            secure = "; Secure" if self.headers.get("X-Forwarded-Proto") == "https" else ""
            self.send_header(
                "Set-Cookie",
                f"{SESSION_COOKIE}={cookie}; Path=/api/v1; Max-Age=2592000; HttpOnly; SameSite=Lax{secure}",
            )
        self.end_headers()
        self.wfile.write(data)

    def session_key(self):
        cookies = SimpleCookie()
        try:
            cookies.load(self.headers.get("Cookie", ""))
        except CookieError:
            return None
        token = cookies.get(SESSION_COOKIE)
        return token.value if token and re.fullmatch(ID, token.value) else None

    def body(self):
        size = self.headers.get("Content-Length", "")
        if not size.isascii() or not size.isdecimal() or len(size) > 6 or int(size) > 65536:
            raise invalid("Недопустимый размер JSON-запроса.", "body")
        if self.headers.get_content_type() != "application/json":
            raise ApiFailure(415, "VALIDATION_ERROR", "Ожидается application/json.")
        try:
            body = json.loads(self.rfile.read(int(size)))
        except (ValueError, RecursionError):
            raise invalid("Отправьте корректный JSON.", "body") from None
        if not isinstance(body, dict):
            raise invalid("Ожидается объект JSON.", "body")
        return body

    def idempotency_key(self):
        key = self.headers.get("Idempotency-Key", "")
        if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", key):
            raise invalid("Укажите корректный Idempotency-Key.", "Idempotency-Key")
        return key

    @staticmethod
    def number(query, name, default, lower, upper):
        raw = query.get(name, [None])[0]
        if raw is None:
            return default
        if not raw.isascii() or not raw.isdecimal() or len(raw) > 15:
            raise invalid(f"Некорректный параметр {name}.", name)
        number = int(raw)
        if number < lower:
            raise invalid(f"Некорректный параметр {name}.", name)
        return min(number, upper)

    def dispatch(self, method):
        try:
            self.route(method)
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            return
        except ApiFailure as exc:
            self.reply(exc.status, {"error": exc.error})
        except SourceNotFound:
            failure = not_found()
            self.reply(failure.status, {"error": failure.error})
        except CatalogUnavailable:
            self.reply(503, {"error": error("CATALOG_UNAVAILABLE", "База знаний недоступна.", retryable=True)})
        except ValueError:
            self.reply(400, {"error": error("VALIDATION_ERROR", "Некорректный запрос.")})
        except Exception as exc:
            LOG.error("HTTP request failed (%s)", type(exc).__name__)
            self.reply(500, {"error": error("INTERNAL_ERROR", "Ошибка сервера.", retryable=True)})

    def route(self, method):
        app = self.server.app
        store = app.store
        url = urlsplit(self.path)
        path = url.path
        if method == "GET" and path == "/api/health":
            app.dispatcher.dispatch(ReadSnapshot())
            return self.reply(200, {"status": "ok"})

        token = self.session_key()
        if method == "GET" and path == f"{API}/knowledge-bases":
            bases = app.dispatcher.dispatch(ListKnowledgeBases())
            session = store.session(token, create=True)
            return self.reply(200, {"items": [asdict(base) for base in bases]}, cookie=session if session != token else None)
        if not path.startswith(f"{API}/"):
            raise not_found()

        session = store.session(token)
        query = parse_qs(url.query, max_num_fields=16)
        if path == f"{API}/conversations":
            if method == "GET":
                limit = self.number(query, "limit", 20, 1, 50)
                offset = self.number(query, "cursor", 0, 0, 10**12)
                return self.reply(200, store.conversations(session, limit, offset))
            kb = self.body().get("knowledge_base_id")
            if not isinstance(kb, str) or kb not in {
                base.id for base in app.dispatcher.dispatch(ListKnowledgeBases())
            }:
                raise invalid("Выберите доступную базу знаний.", "knowledge_base_id")
            return self.reply(201, store.create_conversation(session, kb))

        match = MESSAGES.fullmatch(path)
        if match:
            cid = match[1]
            if method == "GET":
                limit = self.number(query, "limit", 30, 1, 100)
                before = self.number(query, "before_seq", 10**15, 1, 10**15)
                return self.reply(200, store.messages(session, cid, limit, before))
            body = self.body()
            text = body.get("text")
            if not isinstance(text, str) or not 1 <= len(text.strip()) <= 8000:
                raise invalid("Введите вопрос длиной от 1 до 8 000 символов.", "text")
            try:
                text.encode("utf-8")
            except UnicodeEncodeError:
                raise invalid("В вопросе есть некорректные символы.", "text") from None
            as_of = body.get("as_of_date")
            if "as_of_date" in body:
                try:
                    if not isinstance(as_of, str) or date.fromisoformat(as_of).isoformat() != as_of:
                        raise ValueError
                except ValueError:
                    raise invalid("Укажите существующую дату в формате ГГГГ-ММ-ДД.", "as_of_date") from None
            rid, created = store.send(session, cid, self.idempotency_key(), text.strip(), as_of)
            return self.send_run(app, session, rid, created)

        if method == "POST" and (match := RETRY.fullmatch(path)):
            rid, created = store.retry(session, match[1], self.idempotency_key())
            return self.send_run(app, session, rid, created)
        if method == "GET" and (match := RUN.fullmatch(path)):
            return self.reply(200, store.run(session, match[1]))
        if method == "GET" and (match := SOURCE.fullmatch(path)):
            snapshot, kind, identifier = match.groups()
            if kind == "files":
                document = app.dispatcher.dispatch(GetSourceFile(snapshot, identifier))
                return self.reply(200, document.content, content_type="text/plain; charset=utf-8")
            source = asdict(app.dispatcher.dispatch(GetSourceChunk(snapshot, identifier)))
            source["file"]["url"] = f"{API}/sources/{snapshot}/files/{source['file']['id']}"
            return self.reply(200, source)
        raise not_found()

    def send_run(self, app, session, rid, created):
        if created:
            app.queue_run(rid)
        run = app.store.run(session, rid)
        self.reply(202 if run["state"] == "running" else 200, run)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default=env_value("JURION_HOST", default="127.0.0.1"))
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--corpus", type=Path, default=Path(env_value("JURION_CORPUS", default="data/knowledge-base.zip")))
    parser.add_argument("--state-dir", type=Path, default=Path(env_value("JURION_STATE_DIR", default=".jurion")))
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    root = args.state_dir / "catalog"
    catalog = FileCatalog(root)
    dispatcher = Dispatcher(catalog, ProxyGenerator.from_env)
    try:
        if args.corpus.is_file():
            dispatcher.dispatch(PublishSnapshot(args.corpus, root))
        dispatcher.dispatch(ReadSnapshot())
    except (ValueError, OSError, CatalogUnavailable) as exc:
        parser.exit(2, f"База знаний недоступна. Проверьте архив {args.corpus}: {exc}\n")

    with ThreadingHTTPServer((args.host, args.port), Handler) as server:
        app = WebApplication(Store(args.state_dir / "web.sqlite3"), dispatcher, worker_limit())
        server.app = app
        LOG.info("Jurion API listening at %s:%s", *server.server_address)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            app.workers.shutdown(cancel_futures=True)


if __name__ == "__main__":
    main()
