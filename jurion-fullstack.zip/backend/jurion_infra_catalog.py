"""File-backed catalog adapter for immutable, validated snapshots."""

from pathlib import Path

from jurion_corpus import build_snapshot, load_snapshot, publish
from jurion_errors import CatalogUnavailable, SourceNotFound
from jurion_ports import Snapshot


class FileCatalog:
    def __init__(self, root: Path | None = None):
        self.root = root

    def import_archive(self, archive: Path) -> tuple[dict, dict[str, bytes]]:
        return build_snapshot(archive)

    def publish(self, archive: Path, root: Path) -> str:
        return publish(archive, root)

    def load(self, snapshot_id: str | None = None) -> Snapshot:
        try:
            if self.root is None:
                raise ValueError("Catalog root is required")
            sid = (
                snapshot_id
                if snapshot_id is not None
                else (self.root / "active").read_text(encoding="ascii").strip()
            )
            manifest, originals = load_snapshot(self.root, sid)
            return Snapshot(sid, manifest, originals)
        except (ValueError, OSError, KeyError) as exc:
            failure = SourceNotFound if snapshot_id is not None else CatalogUnavailable
            raise failure(
                "Source not found" if snapshot_id is not None else "Catalog unavailable"
            ) from exc
