import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, ".", "");
  const target = env.VITE_API_PROXY_TARGET || "http://127.0.0.1:8000";
  const proxy = { "/api": { target, changeOrigin: true } };
  return {
    plugins: [react()],
    // Относительные пути: сборку можно раздавать из любого подкаталога.
    base: "./",
    server: {
      port: 5173,
      host: true,
      proxy,
    },
    preview: { port: 4173, host: true, proxy },
  };
});
